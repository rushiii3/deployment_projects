# MERN-Todoapp
MERN stack Todo app.

## Preview
<img src="https://user-images.githubusercontent.com/85039185/210167483-c82f7878-26cd-4af7-b9da-ac51f300546c.png" />
